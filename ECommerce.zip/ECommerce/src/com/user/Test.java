package com.user;

import com.model.Cart;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.model.Cart;
import com.model.Product;
import com.model.user;

public class Test {
	public static void main(String[] args) {
		Cart c= new Cart() {

			@Override
			public void YourCart() {
				
				System.out.println("You Want TO Add More Products?");
				System.out.println("Enter 1 for Adding more products");
				System.out.println("Enter 2 for exit");
				
			}
		};
		
		List<Product> products = new ArrayList<>();
        products.add(new Product(101, "SmartPhone", "High-end smartphone with OLED display and 128GB storage", 4.5f, 45000));
        products.add(new Product(102, "Laptop", "15.6-inch Laptop with Intel i7 processor and 16GB RAM", 4.7f, 75000));
        products.add(new Product(103, "Tablet", "10.5 inch tablet with 64GB storage and Stylus Support", 4.3f, 80000));
        products.add(new Product(104, "HeadPhones", "Wireless noise cancelling headphones with 30-hour battery life", 4.4f, 30000));
        products.add(new Product(105, "Smart Watch", "Water resistant smartwatch with heart rate monitor and GPS", 4.5f, 52450));

        List<Product> cart = new ArrayList<>();
		

		Scanner sc= new Scanner(System.in);
		user u1=new user();

		
			
			System.out.println("Welcome to FlipKart(:");
			System.out.println("Register Yourelf First....");
			System.out.println("Enter Your Name:");
			u1.setName(sc.nextLine());
			System.out.println("Enter Your Mobile Number:");
			u1.setMobno(sc.nextLong());
			sc.nextLine();
			System.out.println("Enter Your Email Id:");
			u1.setEmail(sc.nextLine());
			System.out.println("Enter Your Username:");
			u1.setUsername(sc.nextLine());
			System.out.println("Enter Your PassWord:");
			String password = sc.nextLine();
			u1.setPassword(password);
			System.out.println("Confirm Your PassWord:");
			String confirmPassword = sc.nextLine();
	        if (!password.equals(confirmPassword)) {
	            System.out.println("Passwords do not match. Registration failed!");
	            return;
	        }
			System.out.println("Registration Succesfully....!!!");
			

			System.out.println("You can Shop Now....");
			System.out.println("Enter Your Choice Code From below List");
			while(true) {
				
			System.out.println("1.Login");
			System.out.println("2.Logout");
			int ch=sc.nextInt();
			
			switch(ch) {
			
			case 1:{
				System.out.print("Enter Your username or email: ");
                String loginUser = sc.next();
                sc.nextLine();

                System.out.print("Enter Your Password: ");
                String loginPass = sc.next();
                sc.nextLine();

                if ((loginUser.equals(u1.getUsername()) || loginUser.equals(u1.getEmail())) && loginPass.equals(u1.getPassword())) {
                    System.out.println("\nLogin Successful!\n");}
                
				products.forEach(System.out::println);
				System.out.println("Choose product from Above list By Id:");
				System.out.println("Enter id:");
				int pid = sc.nextInt();
				
				c.YourCart();
				break;
				
			}
			
			
			case 2:{
				System.out.println("Logged out..");
				System.exit(0);
				break;
			}
			default:
			{
				System.out.println("Invalid Choice Please Try Again......!");
			}
			
			}
			}
		
	}

}
