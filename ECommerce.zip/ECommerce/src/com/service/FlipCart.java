package com.service;

public class FlipCart {

}
