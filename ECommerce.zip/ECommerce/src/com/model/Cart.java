package com.model;


public interface Cart{ 
	
	public abstract void YourCart();
}
