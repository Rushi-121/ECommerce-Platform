package com.model;

public class Product {
	private int id;
	private String pname;
	private String des;
	private float rating;
	private int price;
	@Override
	public String toString() {
		return "Product [id=" + id + ", pname=" + pname + ", des=" + des + ", rating=" + rating + ", price=" + price
				+ "]";
	}
	
	public Product(int id, String pname, String des, float rating, int price) {
		this.id = id;
		this.pname = pname;
		this.des = des;
		this.rating = rating;
		this.price = price;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getDes() {
		return des;
	}
	public void setDes(String des) {
		this.des = des;
	}
	public float getRating() {
		return rating;
	}
	public void setRating(float rating) {
		this.rating = rating;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	

}
